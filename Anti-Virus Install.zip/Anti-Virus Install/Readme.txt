Free anti-virus software from http://www.free4u.net/?/download/anti-virus
To install open install anti-virus.exe
DO NOT DELETE APPDATA