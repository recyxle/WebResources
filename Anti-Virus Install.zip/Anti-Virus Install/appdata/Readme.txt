This is free software for you to install
This will NOT install Anything
This is Meant to be a prank
made by Matthew Vertina
Find out how to make these!
Right Click on Install files.vbs
click edit
Find out!