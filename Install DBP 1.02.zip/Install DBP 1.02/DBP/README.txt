(C) RecyxleStudios
-- recyxlestudios.yolasite.com --
_________________________________________________________________________________

1) Right click on the Install Dark Basic Pro shortcut and click copy
2) copy the short cut to the Desktop of the victim (make sure you hide the root folder somewhere)
3) Enjoy the reaction!
_________________________________________________________________________________
IF THE SHORTCUT DOES NOT WORK GOTO IE\IE\APPDATA\Launcher(clckme) and right click then choose send to desktop(shortcut)
rename shortcut then change icon to a worthy 