to setup prank rightclick on Launcher(clkme!) and click edit inside is a line saying start wmplayer "C:\users\-place username here-\desktop\IE\APPDATA\musicie.mp3"
place the victems username here (make sure IE folder is placed on desktop!) Happy Pranking!
delete this README from victems copy!

BETA 1.03